import React from 'react';

const Thanks = () => {
    return (
        <div>
            thanckyou!
        </div>
    );
};

export default Thanks;